/**
Gara ABC 2014. Task SEMINA.
Luca Chiodini

Semplice implementazione di quanto richiesto dal testo.
Il problema dei valori negativi viene risolto aggiungendo
un offset di 100 a ogni valore in input.
*/

#include <iostream>
using namespace std;

int rett[200][200];

int main()
{
    int N, a, b, c, d;
    cin >> N;
    for(int i = 0; i < N; i++)
    {
        cin >> a >> b >> c >> d;
        for(int i = 0; i < c - a; i++)
            for(int j = 0; j < b - d; j++)
                rett[a + i + 100][d + j + 100]++;
    }
    int res = -1;
    for(int i = 0; i < 200; i++)
        for(int j = 0; j < 200; j++)
            res = max(res, rett[i][j]);
    cout << res << endl;
}
