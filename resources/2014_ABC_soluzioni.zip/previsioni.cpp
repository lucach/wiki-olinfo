/**
Gara ABC 2014. Task PREVISIONI.
Luca Chiodini

Ricorsivamente decidiamo se cercare a sinistra, nel centro o a destra fino
ad arrivare alla previsione base.
*/

#include <iostream>

using namespace std;

// Restituisce la lunghezza della i-esima previsione
int lunghezza(int i)
{
    if (i == -1)
        return 0;
    return (2*lunghezza(i - 1)) + i + 3;
}

// Restituisce l'n-esimo carattere della i-esima previsione
char risolvi(int n, int i)
{
    if (n > lunghezza(i)) // aumentiamo la lunghezza della previsione
        return risolvi(n, i + 1);
    if (n <= lunghezza(i - 1)) // diminuiamo la lunghezza della previsione
        return risolvi(n, i - 1);
    n -= lunghezza(i - 1);
    if (n <= i + 3) // se è nel mezzo possiamo decidere
        return (n == 1) ? 'P' : 'S';
    return risolvi(n - (i + 3), i - 2);
}

int main()
{
    int n;
    cin >> n;
    cout << risolvi(n, 0) << endl;
}
