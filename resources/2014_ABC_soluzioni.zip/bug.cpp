/**
Gara ABC 2014. Task BUG.
Luca Chiodini

La tipologia è greedy.
Per arrivare alla soluzione ottima, assegniamo ogni volta il bug allo studente,
in grado di risolverlo, che ha costo minore. Per fare ciò efficientemente, si
ricorre all'uso di una coda con priorità.
*/

#include <algorithm>
#include <iostream>
#include <vector>
#include <queue>
using namespace std;

typedef pair<int, int> pii;


bool cmp(pair<int, pii> a, pair<int, pii > b)
{
    return a.second.first > b.second.first;
}

vector <int> res;
vector< pair<int, pii > > students;
vector< pii > bugs;

int nstudents, nbugs, maxpass, tmp;

bool risolvibile(int time)
{
    int now = maxpass, current_stud = 0;
    priority_queue < pii > q;
    for(int i = 0; i < nbugs; i += time)
    {
        // Scorriamo fino allo studente con minore abilità in grado di risolvere
        // comunque il bug.
        while(current_stud < nstudents &&
                students[current_stud].second.first >= bugs[i].first)
        {
            // Lo mettiamo nella coda con priorità ordinata per costo crescente.
            // N.B. Per evitare una funzione cmp personalizzata, "ribaltiamo"
            // la situazione inserendo come costo dello studente il negativo
            // del suo costo reale.
            q.push(make_pair(-students[current_stud].second.second,
                             students[current_stud].first));
            current_stud++;
        }
        if(q.empty())  // nessuno studente è in grado di risolvere il bug
            return false;
        now += q.top().first; // aggiungiamo il costo dello studente meno oneroso
        if(now < 0)  // stiamo distribuendo più "voti" di quanto possibile
            return false;
        for(int k = 0; k < time && i + k < nbugs; k++)
            res[bugs[i + k].second] = q.top().second;
        q.pop();
    }
    return true;
}

int main()
{
    cin >> nstudents >> nbugs >> maxpass;
    for(int i = 0; i < nbugs; i++)
    {
        cin >> tmp;
        bugs.push_back(make_pair(tmp, i));
    }
    for(int i = 0; i < nstudents; i++)
    {
        cin >> tmp;
        // È necessario tenere il riferimento alla posizione dello studente (i)
        students.push_back(make_pair(i, make_pair(tmp, 0)));
    }
    for(int i = 0; i < nstudents; i++)
    {
        cin >> tmp;
        students[i].second.second = tmp;
    }
    res.reserve(nbugs + 1);
    // Ordiniamo i bug in ordine decrescente di difficoltà
    sort(bugs.begin(), bugs.end());
    reverse(bugs.begin(), bugs.end());
    // Ordiniamo gli studenti in ordine decrescente di abilità
    sort(students.begin(), students.end(), cmp);
    // Verifichiamo se un qualsiasi studente è in grado di risolvere il bug
    // più difficile (e quindi è capace di risolverli tutti) a un costo
    // accettabile.
    bool found = false;
    for(int i = 0; i < nstudents; i++)
        if(students[i].second.first >= bugs[0].first
                && students[i].second.second <= maxpass)
            found = true;
    if(found)
        cout << "SI" << endl;
    else
    {
        cout << "NO" << endl;
        return 0;
    }

    // Se siamo qui, sappiamo che sicuramente esiste una soluzione. La cerchiamo
    // a partire dal tempo zero.
    // Come ulteriore ottimizzazione (non richiesta in questa gara) è possibile
    // ottimizzare ulteriormente con una ricerca binaria.

    int i = 0;
    for(; !risolvibile(i); i++);
    risolvibile(i);
    for(int i = 0; i < nbugs; i++)
        cout << res[i] + 1 << " ";
    cout << endl;
}
