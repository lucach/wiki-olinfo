/**
Gara ABC 2014. Task MESSAGGI.
Luca Chiodini

Map è la struttura dati adatta a risolvere efficientemente l'esercizio.
Per ottenere il 50% dei punti si può semplicemente memorizzare un vettore
e ricercare linearmente ogni volta l'username.
*/

#include <iostream>
#include <map>
#include <string>
#include <vector>

using namespace std;

int main()
{
    map <string, vector<string> > inviati, ricevuti;
    int n, r;
    cin >> n >> r;
    string a, b;
    for (int i = 0; i < n; i++)
    {
        cin >> a >> b;
        inviati[a].push_back(b);
        ricevuti[b].push_back(a);
    }
    for (int i = 0; i < r; i++)
    {
        cin >> a >> b;
        vector<string> res;
        vector<string>::iterator it;
        if (b == "INVIATI")
            res = inviati[a];
        else if (b == "RICEVUTI")
            res = ricevuti[a];
        cout << res.size() << " ";
        for (it = res.begin(); it != res.end(); it++)
            cout << *it << " ";
        cout << endl;
    }
}
