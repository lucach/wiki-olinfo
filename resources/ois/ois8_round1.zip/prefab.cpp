#include <stdio.h>
#include <assert.h>
#include <algorithm>

using namespace std;

int assess(int A, int B, int X, int Y) {
    if (A < B) swap(A, B);
    int res = max(0, X*Y - A*B);
    
    if (A >= X and B <= Y) res = min(res, X*((Y-B+1)/2));
    if (A <= X and B >= Y) res = min(res, Y*((X-A+1)/2));
    
    swap(X, Y);
    
    if (A >= X and B <= Y) res = min(res, X*((Y-B+1)/2));
    if (A <= X and B >= Y) res = min(res, Y*((X-A+1)/2));
    
    return res;
}


int main() {
    FILE *fr, *fw;
    int A, B, X, Y;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(4 == fscanf(fr, "%d %d %d %d", &A, &B, &X, &Y));

    fprintf(fw, "%d\n", assess(A, B, X, Y));
    fclose(fr);
    fclose(fw);
    return 0;
}
