#include <stdio.h>
#include <assert.h>

#define MAXN 100000

int kindle(int N, int M, int K, int L[]) {
    int counter = 0, res = 0;
    for (int i=0; i<M; i++) counter += L[i];
	for (int i=M-1; counter < K; i--)
		if (L[i] == 0)
			L[i] = 1, counter++, res++;
    counter -= K;
    for (int i=M; i<N; i++) {
        counter += L[i] - L[i-M];
        if (counter < 0) {
            counter = 0;
			L[i] = 1;
            res++;
        }
    }
    return res;
}


int L[MAXN];

int main() {
    FILE *fr, *fw;
    int N, M, K, i;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(3 == fscanf(fr, "%d %d %d", &N, &M, &K));
    for(i=0; i<N; i++)
        assert(1 == fscanf(fr, "%d", &L[i]));

    fprintf(fw, "%d\n", kindle(N, M, K, L));
    fclose(fr);
    fclose(fw);
    return 0;
}
