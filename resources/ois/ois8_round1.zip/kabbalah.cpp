#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <algorithm>

using namespace std;

int search(int x0, int y0, int dx, int dy, int len, char** C) {
    char prev = ' ';
    int res = 0, cur = 1;
    for (int i=0; i<len; i++) {
        int x = x0+i*dx;
        int y = y0+i*dy;
        if (C[x][y] == prev) cur++;
        else {
            res = max(res, cur);
			prev = C[x][y];
            cur = 1;
        }
    }
    return max(res, cur);
}

int decipher(int N, int M, char** C) {
    int res = 0;
    for (int x=0; x<N; x++) res = max(res, search(x, 0, 0, 1, M, C));
    for (int y=0; y<M; y++) res = max(res, search(0, y, 1, 0, N, C));
    for (int x=0; x<N; x++) res = max(res, search(x, 0, 1, 1, min(M,N-x), C));
    for (int y=0; y<M; y++) res = max(res, search(0, y, 1, 1, min(N,M-y), C));
    for (int x=0; x<N; x++) res = max(res, search(x, M-1, 1, -1, min(M,N-x), C));
    for (int y=0; y<M; y++) res = max(res, search(0, y, 1, -1, min(N,y), C));
    return res;
}


int main() {
    FILE *fr, *fw;
    int N, M, i;
    char** C;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(2 == fscanf(fr, "%d%d", &N, &M));
    C = (char**) malloc(N * sizeof(char*));
    for(i=0; i<N; i++) {
        C[i] = (char*) malloc(M * sizeof(char*));
        assert(1 == fscanf(fr, "%s", C[i]));
    }

    fprintf(fw, "%d\n", decipher(N, M, C));
    fclose(fr);
    fclose(fw);
    return 0;
}
