#include <bits/stdc++.h>

const int SEAT_AVAILABLE = -1;
const int NON_EXISTENT = -1;

std::set<int> available;
std::vector<int> seat;
std::vector<int> where;

int fix_people(int person) {
    int offender = seat[person];
    seat[person] = where[person] = person;

    if (seat[offender] == SEAT_AVAILABLE) {
        seat[offender] = where[offender] = offender;

		auto my_seat = available.find(offender);
		assert(my_seat != available.end());

		available.erase(my_seat);
        return 1;
    } else {
        return 1 + fix_people(offender);
    }
}

int main() {
    int N, Q;
    std::cin >> N >> Q;

    seat.resize(N, SEAT_AVAILABLE);
    where.resize(N, NON_EXISTENT);

    for (int i = 0; i < N; i++) {
        available.insert(i);
    }

    int answer = 0;

    for (int i = 0; i < Q; i++) {
        int reservation;
        std::string event;

        std::cin >> event >> reservation;

        if (event[0] == 'b') {
            auto leftmost = available.begin();

            // The task constraints guarantee that 'leftmost' is valid, here
            assert(leftmost != available.end());

            if (*leftmost <= reservation) {
                // I can sit!
                seat[*leftmost] = reservation;
                where[reservation] = *leftmost;
                available.erase(leftmost);
            } else {
                // Someone stole my seat!
                answer += fix_people(reservation);
            }
        } else {
            // The task constraints guarantee that this person exists somewhere
            assert(where[reservation] != NON_EXISTENT);

            available.insert(where[reservation]);

            seat[where[reservation]] = SEAT_AVAILABLE;
            where[reservation] = NON_EXISTENT;
        }
    }

    std::cout << answer << std::endl;
}
