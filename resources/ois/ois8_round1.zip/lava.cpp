#include <bits/stdc++.h>

std::vector<std::string> s;

int di[] = {-1, -1, -2, -1, 0, 0, 0, 0, 1, 1, 2, 1};
int dj[] = {-1, 0, 0, 1, -1, -2, 1, 2, -1, 0, 0, 1};

int H, W;

std::vector<std::vector<bool>> visited;

int bfs(int si, int sj, int ei, int ej) {
    std::queue<std::tuple<int, int, int>> q;

    q.push({0, si, sj});
    while (!q.empty()) {
        int w = std::get<0>(q.front());
        int i = std::get<1>(q.front());
        int j = std::get<2>(q.front());
        q.pop();

        if (visited[i][j]) {
            continue;
        } else {
            visited[i][j] = 1;
        }

        if (i == ei && j == ej) {
            return w;
        }

        for (int k = 0; k < 12; ++k) {
            if (0 <= i + di[k] && i + di[k] < H &&
                    0 <= j + dj[k] && j + dj[k] < W &&
                    s[i + di[k]][j + dj[k]] != '#') {
                q.push(std::make_tuple(w + 1, i + di[k], j + dj[k]));
            }
        }
    }

    return -1;
}

int main() {
    std::cin >> H >> W;

    s.resize(H);
    for (int i = 0; i < H; ++i) {
        std::cin >> s[i];
    }

    visited.resize(H, std::vector<bool>(W, false));
    std::cout << bfs(0, 0, H - 1, W - 1) << std::endl;
}
