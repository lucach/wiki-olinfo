#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <vector>
#include <iostream>
#include <algorithm>

#define MAXN 20000
#define MAXM 20000

using namespace std;

vector<int> FLOPs[2];
int L10 = 0, L16 = 0, bipasso = 0;

int earn(int N, int M, int F[], char** T, char **S) {
    for (int i=0; i<N; i++) {
        if (strncmp(T[i], "L10", 16) == 0)
            FLOPs[0].push_back(F[i]);
        else FLOPs[1].push_back(F[i]);
    }
    for (int i=0; i<M; i++) {
        if (strncmp(S[i], "L10", 16) == 0) L10++;
        if (strncmp(S[i], "L16", 16) == 0) L16++;
        if (strncmp(S[i], "bipasso", 16) == 0) bipasso++;
    }
    sort(FLOPs[0].begin(), FLOPs[0].end());
    sort(FLOPs[1].begin(), FLOPs[1].end());

	int res = 0;
    for (int i=0; i<L10; i++) if (!FLOPs[0].empty()) {
        res += FLOPs[0].back();
        FLOPs[0].pop_back();
    }
    for (int i=0; i<L16; i++) if (!FLOPs[1].empty()) {
        res += FLOPs[1].back();
        FLOPs[1].pop_back();
    }

	FLOPs[0].insert(FLOPs[0].end(), FLOPs[1].begin(), FLOPs[1].end());
    sort(FLOPs[0].begin(), FLOPs[0].end());
    for (int i=0; i<bipasso; i++) if (!FLOPs[0].empty()) {
        res += FLOPs[0].back();
        FLOPs[0].pop_back();
    }

    return res;
}


int F[MAXN];
char* T[MAXN];
char* S[MAXM];

int main() {
    FILE *fr, *fw;
    int N, M, i;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(2 == fscanf(fr, "%d%d", &N, &M));
    for(i=0; i<N; i++)
        assert(1 == fscanf(fr, "%d", &F[i]));
    for(i=0; i<N; i++) {
        T[i] = (char*) malloc(16 * sizeof(char*));
        assert(1 == fscanf(fr, "%s", T[i]));
    }
    for(i=0; i<M; i++) {
        S[i] = (char*) malloc(16 * sizeof(char*));
        assert(1 == fscanf(fr, "%s", S[i]));
    }

    fprintf(fw, "%d\n", earn(N, M, F, T, S));
    fclose(fr);
    fclose(fw);
    return 0;
}
