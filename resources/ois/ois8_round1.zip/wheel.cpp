#include <stdio.h>
#include <assert.h>
#include <algorithm>

#define MAXN 100000
#define MAXQ 100000

using namespace std;

int Min[2*MAXN];
int Max[2*MAXN];

struct maxQueue {
    int Values[2*MAXN], Count[2*MAXN];
    int begin, end;
    maxQueue() : begin(0), end(0) {};
    int max() {
        return Values[begin];
    }
    void pop() {
        Count[begin]--;
        if (Count[begin] == 0) begin++;
    }
    int push(int x) {
        int c = 1;
        while (end > begin and Values[end-1] <= x) {
            c += Count[end-1];
            end--;
        }
        Values[end] = x;
        Count[end] = c;
        end++;
    }
};

FILE *fr, *fw;
maxQueue minQ, maxQ;

void info(int mn, int mx) {
    fprintf(fw, "%d %d\n", mn, mx);
}

void win(int N, int W[], int Q, int K[]) {
    for (int i=0; i<N; i++) {
        maxQ.push(W[i]);
        minQ.push(-W[i]);
    }
    for (int i=0; i<2*N; i++) {
        Max[i] = maxQ.max();
        Min[i] = -minQ.max();
        maxQ.pop();
        minQ.pop();
        maxQ.push(W[(i+N)%(2*N)]);
        minQ.push(-W[(i+N)%(2*N)]);
    }
    int offs = 0;
    for (int i=0; i<Q; i++) {
        offs = (offs + 2*N - K[i])%(2*N);
        info(Min[offs], Max[(offs+N)%(2*N)]);
    }
}


int W[2*MAXN];
int K[MAXN];

int main() {
    int N, Q, i;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(1 == fscanf(fr, "%d", &N));
    for(i=0; i<2*N; i++)
        assert(1 == fscanf(fr, "%d", &W[i]));
    assert(1 == fscanf(fr, "%d", &Q));
    for(i=0; i<Q; i++)
        assert(1 == fscanf(fr, "%d", &K[i]));

    win(N, W, Q, K);
    fclose(fr);
    fclose(fw);
    return 0;
}
