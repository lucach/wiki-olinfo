#include <bits/stdc++.h>

int main() {
    int N;
    std::cin >> N;

    std::vector<std::string> users(N);
    for (int i = 0; i < N; i++) {
        std::cin >> users[i];
    }

    std::set<std::string> seen;
    for (auto it = users.rbegin(); it != users.rend(); it++) {
        if (!seen.count(*it)) {
            std::cout << *it << std::endl;
            seen.insert(*it);
        }
    }
}
