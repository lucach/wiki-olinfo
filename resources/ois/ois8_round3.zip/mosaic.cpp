#include <bits/stdc++.h>

const int MAXA = 10;
const int MAXB = 50;
const int MAXN = 5000;

int A, B;
int N;

int up[MAXN], down[MAXN], left[MAXN], right[MAXN];
bool used[MAXN];

std::vector<int> idx_up[1 << MAXA];
std::vector<int> idx_down[1 << MAXA];
std::vector<int> idx_left[1 << MAXA];
std::vector<int> idx_right[1 << MAXA];

int sol[MAXB][MAXB];

void print() {
    for (int i = 0; i < B; i++) {
        for (int j = 0; j < B; j++) {
            std::cout << sol[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

void bt(int a, int b) {
    if (a == B) {
        // wow
        print();
        exit(0);
    }

    if (a == 0 && b == 0) {
        for (int i = 0; i < N; i++) {
            // try this
            used[i] = 1;
            sol[a][b] = i;

            bt(a, b + 1);

            // nevermind
            used[i] = 0;
        }
    }

    if (a > 0 && b == 0) {
        for (int i : idx_up[down[sol[a - 1][b]]]) if (!used[i]) {
            // try this
            used[i] = 1;
            sol[a][b] = i;

            bt(a, b + 1);

            // nevermind
            used[i] = 0;
        }
    }

    if (a == 0 && b > 0) {
        for (int i : idx_left[right[sol[a][b - 1]]]) if (!used[i]) {
            // try this
            used[i] = 1;
            sol[a][b] = i;

            if (b == B - 1)
                bt(a + 1, 0);
            else
                bt(a, b + 1);

            // nevermind
            used[i] = 0;
        }
    }

    if (a > 0 && b > 0) {
        if (idx_left[right[sol[a][b - 1]]].size() < idx_up[down[sol[a - 1][b]]].size()) {
            for (int i : idx_left[right[sol[a][b - 1]]]) if (!used[i] && up[i] == down[sol[a - 1][b]]) {
                // try this
                used[i] = 1;
                sol[a][b] = i;

                if (b == B - 1)
                    bt(a + 1, 0);
                else
                    bt(a, b + 1);

                // nevermind
                used[i] = 0;
            }
        } else {
            for (int i : idx_up[down[sol[a - 1][b]]]) if (!used[i] && left[i] == right[sol[a][b - 1]]) {
                // try this
                used[i] = 1;
                sol[a][b] = i;

                if (b == B - 1)
                    bt(a + 1, 0);
                else
                    bt(a, b + 1);

                // nevermind
                used[i] = 0;
            }
        }
    }
}

int main() {
    std::cin >> A >> B;
    std::cin >> N;

    for (int i = 0; i < N; i++) {
        char s[MAXA][MAXA];

        for (int j = 0; j < A; j++) {
            std::cin >> s[j];
        }

        for (int j = 0; j < A; j++) {
            if (s[0][j] == '1')
                up[i] |= (1 << j);
            if (s[A - 1][j] == '1')
                down[i] |= (1 << j);
            if (s[j][0] == '1')
                left[i] |= (1 << j);
            if (s[j][A - 1] == '1')
                right[i] |= (1 << j);
        }

        idx_up[up[i]].push_back(i);
        idx_down[down[i]].push_back(i);
        idx_left[left[i]].push_back(i);
        idx_right[right[i]].push_back(i);
    }

    bt(0, 0);
}
