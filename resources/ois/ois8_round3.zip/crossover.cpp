#include <stdio.h>
#include <assert.h>
#include <string.h>

#define MAXL 100008

int crossover(char s[], int sl, char t[], int tl, char result[]) {
    if (sl == 0) {
        for (int i=0; i<tl; i++) result[i] = t[i];
        return tl;
    }
    if (tl == 0) {
        for (int i=0; i<sl; i++) result[i] = s[i];
        return sl;
    }
    if (s[0] == t[tl-1])
        return crossover(t, tl-1, s+1, sl-1, result);
    result[0] = t[tl-1];
    int n = crossover(s+1, sl-1, t, tl-1, result+1);
    result[n+1] = s[0];
    return n+2;
}


char s[MAXL];
char t[MAXL];
char r[2*MAXL];

int main() {
    FILE *fr, *fw;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(2 == fscanf(fr, "%s %s", s, t));

    r[crossover(s, strlen(s), t, strlen(t), r)] = 0;
    fprintf(fw, "%s\n", r);
    fclose(fr);
    fclose(fw);
    return 0;
}
