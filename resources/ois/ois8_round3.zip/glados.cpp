#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

int H, W, R, C, i;
char** M;

int dr[4] = {0,-1, 0, 1};
int dc[4] = {1, 0,-1, 0};

bool valid(int r, int c) {
    bool t = 0 <= r and r < H and 0 <= c and c < W and M[r][c] != '#';
    return t;
}

int main() {
    FILE *fr, *fw;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(4 == fscanf(fr, "%d %d %d %d", &H, &W, &R, &C));
    M = (char**) malloc(H * sizeof(char*));
    for(i=0; i<H; i++) {
        M[i] = (char*) malloc((W + 1) * sizeof(char));
        assert(1 == fscanf(fr, "%s", M[i]));
    }
    
    int dir = 0;
    for (int i=0; i<H; i++) for (int j=0; j<W; j++) if (M[i][j] == '.') M[i][j] = '0';
    while (M[R][C] >= '0' and M[R][C] <= '3') {
        M[R][C]++;
        for (int d=0; d<4; d++) if (valid(R+dr[(dir+d)%4],C+dc[(dir+d)%4])) {
            R += dr[(dir+d)%4];
            C += dc[(dir+d)%4];
            dir = (dir+d+3)%4;
            break;
        }
    }
    if (M[R][C] == '@') fprintf(fw, "stuck\n");
    if (M[R][C] == 'O') fprintf(fw, "free\n");
    if (M[R][C] == '4') fprintf(fw, "cycling\n");
    fclose(fr);
    fclose(fw);
    return 0;
}
