#include <bits/stdc++.h>

const int MAXT = 3600;
const int MAXN = 200;
const int MAXK = 200;
const int INFTY = MAXT * MAXN + 1;

int N, K, T;
int v[MAXN + 1];

int dp[MAXN + 1][MAXN][MAXK][2];

int f(int idx, int height, int increases, bool increase_in_progress) {
    if (increases > K)
        return INFTY;

    if (idx == N) {
        if (increase_in_progress)
            return INFTY;
        else
            return 0;
    }

    int &ret = dp[idx][height][increases][increase_in_progress];
    if (ret != -1)
        return ret;

    ret = std::numeric_limits<int>::max();

    if (increase_in_progress) {
        // either increase again (if it makes sense)...
        if (height < N)
            ret = std::min(ret, f(idx, height + 1, increases, true));

        // ...or stop increasing
        ret = std::min(ret, f(idx, height, increases + 1, false));
    } else {
        // either try to go on without increasing (if possible)...
        if (height >= idx + 1) {
            int area = (v[idx + 1] - v[idx]) * height;
            ret = std::min(ret, area + f(idx + 1, height, increases, false));
        }

        // ...or try to increase (if it makes sense)
        if (height < N)
            ret = std::min(ret, f(idx, height + 1, increases, true));
    }

    return ret;
}

int main() {
    std::cin >> T >> K;
    std::cin >> N;

    for (int i = 0; i < N; i++) {
        std::cin >> v[i];
    }

    v[N] = T;

    memset(dp, -1, sizeof dp);
    std::cout << f(0, 0, 0, false) << std::endl;
}
