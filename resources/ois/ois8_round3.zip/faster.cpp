#include <bits/stdc++.h>

int main() {
    std::string trigger;
    int N;

    std::cin >> trigger;
    std::cin >> N;

    int i = 0;
    int step = 1;

    int answer = 0;

    while (i < N) {
        answer += 1;

        int increase = 0;
        for (int j = 0; j < step && i < N; j++, i++) {
            std::string word;
            std::cin >> word;

            if (word == trigger) {
                increase += 1;
            }
        }
        step += increase;
    }

    std::cout << answer << std::endl;
}
