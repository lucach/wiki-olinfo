#include <algorithm>
#include <stdio.h>
#include <assert.h>

using namespace std;

int main() {
    FILE *fr, *fw;
    int H, W, X;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(3 == fscanf(fr, "%d %d %d", &X, &H, &W));
    
    int offs[5] = {0,0,1,-1,0};
    if (W%2 == 0)
        for (int i=0; i<H; i++) for (int j=0; j<W; j++) fprintf(fw, "%d ", (j+(i/2)%2)%W);
    else
        for (int i=0; i<H; i++) for (int j=0; j<W; j++) fprintf(fw, "%d ", min(max(0,j+offs[i%4+H%2]),W-1));
    fprintf(fw, "\n");
    
    fclose(fr);
    fclose(fw);
    return 0;
}
