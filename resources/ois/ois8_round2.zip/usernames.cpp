#include <stdio.h>
#include <iostream>
#include <assert.h>

#define MAXN 10000
#define MAXL 64

long long tonum(char* s) {
    long long r = 0;
    int p;
    for (int i=0; s[i] > 0; i++) {
        if (s[i] <= '9') p = s[i] - '0';
        else p = s[i] - 'a' + 10;
        r |= 1LL << p;
    }
    return r;
}

long long L[MAXN];

int invalid(int N, char U[][MAXL]) {
    int count = 0;
    for (int i=0; i<N; i++) L[i] = tonum(U[i]);
    for (int i=0; i<N; i++)
        for (int j=0; j<N; j++)
            if (i!=j and (L[i]&L[j]) == L[i])
                count++;
    return count;
}


char U[MAXN][MAXL];

int main() {
    FILE *fr, *fw;
    int N, i;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(1 == fscanf(fr, "%d", &N));
    for(i=0; i<N; i++)
        assert(1 == fscanf(fr, "%s", U[i]));

    fprintf(fw, "%d\n", invalid(N, U));
    fclose(fr);
    fclose(fw);
    return 0;
}
