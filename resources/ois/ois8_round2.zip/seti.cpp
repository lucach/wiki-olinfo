#include <stdio.h>
#include <assert.h>

#define MAXN 1024000

int D[MAXN];

int solve(int N, int V[]) {
    D[0] = 1;
    for (int i=0; i<N; i++)
        D[i+1] = (D[i]+D[i-V[i]])%1000000007;
    return D[N];
}


int V[MAXN];

int main() {
    FILE *fr, *fw;
    int N, i;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(1 == fscanf(fr, "%d", &N));
    for(i=0; i<N; i++)
        assert(1 == fscanf(fr, "%d", &V[i]));

    fprintf(fw, "%d\n", solve(N, V));
    fclose(fr);
    fclose(fw);
    return 0;
}
