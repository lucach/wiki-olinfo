#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <deque>
#include <algorithm>

#define MAXL 1024

using namespace std;

struct point {
    int x, y, d;
    
    point(int nx, int ny, int nd) : x(nx), y(ny), d(nd) {}
};

bool visited[MAXL][MAXL];
int  H, W;
char **C;

inline void push(deque<point>& q, int x, int y, int d) {
    if (x<0 or x>=W or y<0 or y>=H or C[y][x] == '#' or visited[y][x]) return;
    q.push_back(point(x,y,d));
    visited[y][x] = true;
}

int bfs_find(int Xs, int Ys, char goal) {
    deque<point> pending;
    pending.push_back(point(Xs,Ys,0));
    for (int i=0; i<H; i++)
        for (int j=0; j<W; j++)
            visited[i][j] = false;
    visited[Ys][Xs] = true;
    while (not pending.empty()) {
        point p = pending.front();
        if (C[p.y][p.x] == goal) return p.d;
        pending.pop_front();
        push(pending, p.x-1, p.y, p.d+1);
        push(pending, p.x+1, p.y, p.d+1);
        push(pending, p.x, p.y-1, p.d+1);
        push(pending, p.x, p.y+1, p.d+1);
    }
    return MAXL*MAXL;
}

int persuade(int H, int W, char** C) {
    ::H = H;
    ::W = W;
    ::C = C;
    int Cx, Cy, Mx, My;
    for (int i=0; i<H; i++)
        for (int j=0; j<W; j++) {
            if (C[i][j] == 'C') Cx = j, Cy = i;
            if (C[i][j] == 'M') Mx = j, My = i;
        }
    int Cd = bfs_find(Cx, Cy, '@');
    int Md = bfs_find(Mx, My, '@');
    return min(bfs_find(Cx, Cy, 'M'), Cd+Md+1);
}


int main() {
    FILE *fr, *fw;
    int H, W, i;
    char** C;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(2 == fscanf(fr, "%d%d", &H, &W));
    C = (char**) malloc(H * sizeof(char*));
    for(i=0; i<H; i++) {
        C[i] = (char*) malloc((W + 1) * sizeof(char));
        assert(1 == fscanf(fr, "%s", C[i]));
    }

    fprintf(fw, "%d\n", persuade(H, W, C));
    fclose(fr);
    fclose(fw);
    return 0;
}
