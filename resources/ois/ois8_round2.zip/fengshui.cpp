#include <stdio.h>
#include <assert.h>
#include <set>

#define MAXN 50000

using namespace std;

set<pair<int,int>> L;

int harmonize(int N, int X[], int Y[]) {
    int size = 0;
    for (int i=0; i<N; i++) L.insert(make_pair(X[i],Y[i]));
    for (auto i=L.begin(); i!=L.end(); ++i)
        for (auto j=next(i); j!=L.end() and i->first == j->first; ++j) {
            int nx = i->first + j->second - i->second;
            if (L.count(make_pair(nx, i->second)) and L.count(make_pair(nx, j->second)))
                size = max(size, j->second - i->second);
        }
    return size;
}


int X[MAXN];
int Y[MAXN];

int main() {
    FILE *fr, *fw;
    int N, i;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(1 == fscanf(fr, "%d", &N));
    for(i=0; i<N; i++)
        assert(2 == fscanf(fr, "%d %d", &X[i], &Y[i]));

    fprintf(fw, "%d\n", harmonize(N, X, Y));
    fclose(fr);
    fclose(fw);
    return 0;
}
