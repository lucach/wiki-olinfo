#include <stdio.h>
#include <assert.h>
#include <deque>
#include <vector>
#include <unordered_set>

#define MAXV 1000000000

using namespace std;

unordered_set<int> visited;
deque<pair<int,int>> queue;

inline void push(int x, int d) {
    if (x > MAXV or visited.count(x)) return;
    queue.push_back(make_pair(x,d));
    visited.insert(x);
}

int empty(int N) {
    queue.push_back(make_pair(N,0));
    visited.insert(N);
    while (not queue.empty()) {
        int v = queue.front().first;
        int d = queue.front().second;
        if (v == 0) return d;
        queue.pop_front();
        push(v+1, d+1);
        push(v-1, d+1);
        push(v*2, d+1);
        while (v % 3 == 0) {
            v /= 3;
            push(v, d+1);
        }
    }
}


int main() {
    FILE *fr, *fw;
    int N, i;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(1 == fscanf(fr, "%d", &N));
    fprintf(fw, "%d\n", empty(N));
    fclose(fr);
    fclose(fw);
    return 0;
}
