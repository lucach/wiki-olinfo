#include <bits/stdc++.h>
using namespace std;

int main() {
    int N;
    cin >> N;

    vector<int> S(N);
    for (int i=0; i<N; i++)
        cin >> S[i];

    int best = 0;

    vector<int> dp(N);
    for (int i=0; i<N; i++) {
        dp[i] = 1;

        for (int j=0; j<i; j++)
            if (S[i] < S[j] || (S[i] > S[j] && S[i] % S[j] == 0))
                dp[i] = max(dp[i], dp[j] + 1);

        best = max(best, dp[i]);
    }

    cout << N - best << endl;
}
