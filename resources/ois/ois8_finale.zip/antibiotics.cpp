#include <stdio.h>
#include <assert.h>
#include <algorithm>
#include <set>

#define MAXN 100000

using namespace std;

set<int> R;

int plan(int N, int T, int H[]) {
    sort(H, H+N);
    for (int i=N-1; i>=0; i--) {
        R.insert(H[i]%T);
        if (R.size() == T) return H[i]+T;
    }
    for (int i=0; i<T; i++)
        if (not R.count(i))
            return i;
}


int H[MAXN];

int main() {
    FILE *fr, *fw;
    int N, T, i;
    
#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(2 == fscanf(fr, "%d %d", &N, &T));
    for(i=0; i<N; i++)
        assert(1 == fscanf(fr, "%d", &H[i]));
    
    fprintf(fw, "%d\n", plan(N, T, H));
    fclose(fr);
    fclose(fw);
    return 0;
}
