#include <stdio.h>
#include <assert.h>
#include <map>
#include <set>

#define MAXN 100000

using namespace std;

set<int> trends;
map<int,int> freqs;
int maxfreq;

int trend(int N, int G[]) {
    for (int i=0; i<N; i++) {
        freqs[G[i]]++;
        if (freqs[G[i]] >= maxfreq) {
            maxfreq = freqs[G[i]];
            trends.insert(G[i]);
        }
    }
    return trends.size();
}


int G[MAXN];

int main() {
    FILE *fr, *fw;
    int N, i;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(1 == fscanf(fr, "%d", &N));
    for(i=0; i<N; i++)
        assert(1 == fscanf(fr, "%d", &G[i]));

    fprintf(fw, "%d\n", trend(N, G));
    fclose(fr);
    fclose(fw);
    return 0;
}
