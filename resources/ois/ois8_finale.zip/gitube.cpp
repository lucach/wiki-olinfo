#include <bits/stdc++.h>
using namespace std;

char choose(int tot) {
    if (tot >= 20) return 'O';
    if (tot >= 10) return 'o';
    return '.';
}

int main() {
    int D, N;
    cin >> D >> N;

    vector<int> day(D, 0);

    for (int commit_day, i = 0; i < N; i++) {
        cin >> commit_day;
        day[commit_day - 1] += 1;
    }

    for (int i = 0; i < 7; i++) {
        for (int dd = i; dd < D; dd += 7) {
            cout << choose(day[dd]);
        }

        cout << endl;
    }
}
