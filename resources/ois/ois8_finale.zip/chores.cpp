#include <bits/stdc++.h>
using namespace std;

int N;
vector<vector<int>> adj;

pair<int, int> farthest(int start) {
    queue<int> q;
    vector<int> dist(N, numeric_limits<int>::max());

    dist[start] = 0;
    q.push(start);

    while (!q.empty()) {
        int node = q.front();
        q.pop();

        for (auto u : adj[node]) {
            if (dist[u] > dist[node] + 1) {
                dist[u] = dist[node] + 1;
                q.push(u);
            }
        }
    }

    int best = 0;
    for (int u = 1; u < N; u++) {
        if (dist[u] > dist[best]) {
            best = u;
        }
    }

    return {best, dist[best]};
}

int main() {
    cin >> N;
    adj.resize(N);

    for (int i = 0; i < N - 1; i++) {
        int a, b;
        cin >> a >> b;

        adj[a].push_back(b);
        adj[b].push_back(a);
    }

    cout << 2 * farthest(farthest(0).first).second << endl;
}
