#include <stdio.h>
#include <assert.h>
#include <algorithm>

#define MAXN 1000
#define K   -0.5
#define ERR  1.0e-6

using namespace std;

int V[MAXN];
double Kexp[MAXN+1];
double Smart[2][MAXN+1]; // 0 -> from L, 1 -> from R
int DP[MAXN][MAXN];
bool DR[MAXN][MAXN];

void giorgio_preprocess(int N) {
    Kexp[0] = 1;
    for (int i=1; i<=N; i++)
        Kexp[i] = K * Kexp[i-1];
    Smart[1][0] = 0;
    for (int i=0; i<N; i++)
        Smart[1][i+1] = V[i] + K * Smart[1][i];
    Smart[0][N] = 0;
    for (int i=N-1; i>=0; i--)
        Smart[0][i] = V[i] + K * Smart[0][i+1];
}

char giorgio_move(int A, int B) {
    double r = Kexp[B-A+1];
    double L = Smart[0][A] - Smart[0][B+1] * r;
    double R = Smart[1][B+1] - Smart[1][A] * r;
    if (L > R+ERR) return 'L';
    if (R > L+ERR) return 'R';
    return 'X';
}

int calc_dp(int A, int B, int player) {
    if (DP[A][B] >= 0) return DP[A][B];
    if (A > B) return 0;
    char m = giorgio_move(A, B);
    if (player or m == 'X') {
        int L = V[A]*player + calc_dp(A+1, B, 1-player);
        int R = V[B]*player + calc_dp(A, B-1, 1-player);
        DR[A][B] = L > R;
        DP[A][B] = max(L, R);
        return DP[A][B];
    }
    DR[A][B] = m == 'L';
    DP[A][B] = m == 'L' ? calc_dp(A+1,B,1-player) : calc_dp(A,B-1,1-player);
    return DP[A][B];
}

void william_preprocess(int N) {
    for (int A=0; A<N; A++)
        for (int B=A; B<N; B++)
            DP[A][B] = -1;
    for (int A=0; A<N; A++)
        DP[A][A] = V[A] * (N%2);
    calc_dp(0,N-1,1);
}

char get_move(int A, int B) {
    return DR[A][B] ? 'L' : 'R';
}

void move(FILE *fw, char m, int& A, int& B) {
    fprintf(fw, "%c", m);
    if (m == 'L') A++;
    else B--;
}

int main() {
    FILE *fr, *fw;
    int N, i;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(1 == fscanf(fr, "%d", &N));
    for(i=0; i<N; i++)
        assert(1 == fscanf(fr, "%d", &V[i]));

    giorgio_preprocess(N);
    william_preprocess(N);
    int A = 0, B = N-1;
    while (A <= B) {
        move(fw, get_move(A,B), A, B);
    }
    fprintf(fw, "\n");
    fclose(fr);
    fclose(fw);
    return 0;
}
