#include <bits/stdc++.h>
using namespace std;

int get(vector<int>& ft, size_t idx) {
    int ret = 0;
    while (idx > 0) {
        ret += ft[idx];
        idx -= idx & (-idx);
    }
    return ret;
}

void inc(vector<int>& ft, size_t idx) {
    while (idx < ft.size()) {
        ft[idx] += 1;
        idx += idx & (-idx);
    }
}

int main() {
    int N;
    cin >> N;

    vector<int> v(N);
    vector<int> answer(N);
    vector<int> ft1(N + 1);
    vector<int> ft2(N + 1);

    for (int i = 0; i < N; i++) {
        cin >> v[i];
    }

    for (int i = 0; i < N; i++) {
        answer[i] += get(ft1, N - v[i] + 1);
        inc(ft1, N - v[i] + 1);
    }

    for (int i = N - 1; i >= 0; i--) {
        answer[i] += get(ft2, v[i]);
        inc(ft2, v[i]);
    }

    for (int i = 0; i < N; i++) {
        if (i > 0) cout << " ";
        cout << answer[i];
    }
    cout << endl;
}
