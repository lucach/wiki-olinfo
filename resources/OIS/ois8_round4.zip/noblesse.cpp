#include <stdio.h>
#include <assert.h>
#include <algorithm>

#define MAXN 1000
#define INF  10000000

using namespace std;

int D[MAXN][MAXN][2];
int X[MAXN];
int N, K;


int book(int i, int k, bool taken) {
    if (i+k > N or k < 0) return 0;
    if (i == N-1) return k==taken ? INF : 0;
    if (D[i][k][taken] > 0) return D[i][k][taken];
    D[i][k][taken] = max(min(book(i+1, k-taken, 1-taken), X[i+1]-X[i]), book(i+1, k-taken, taken));
    return D[i][k][taken];
}

int book(int N, int K, int X[]) {
    return max(book(0, K, false), book(0, K, true));
}


int main() {
    FILE *fr, *fw;
    int i;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(2 == fscanf(fr, "%d %d", &N, &K));
    for(i=0; i<N; i++)
        assert(1 == fscanf(fr, "%d", &X[i]));

    fprintf(fw, "%d\n", book(N, K, X));
    fclose(fr);
    fclose(fw);
    return 0;
}
