#include <bits/stdc++.h>
using namespace std;

struct info_t {
    int t, u;

    bool operator < (const info_t& other) const {
        return t < other.t;
    }

    bool operator ^ (const info_t& other) const {
        return t + u < other.t && other.t - other.u > t;
    }
};

int main() {
    int N;
    cin >> N;

    vector<info_t> v(N);

    for (int i = 0; i < N; ++i) {
        cin >> v[i].t >> v[i].u;
    }
    sort(v.begin(), v.end());

    vector<int> dp(N, 1);
    int answer = 0;

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < i; j++)
            if (v[j] ^ v[i])
                dp[i] = max(dp[i], dp[j] + 1);

        answer = max(answer, dp[i]);
    }

    cout << answer << endl;
}
