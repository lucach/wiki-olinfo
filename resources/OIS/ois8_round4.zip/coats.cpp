#include <stdio.h>
#include <assert.h>

#define MAXN 100000

double estimate(int N, int C[]) {
    int Counts[4] = {0,0,0,0};
    for (int i=0; i<N; i++) Counts[C[i]]++;
    return Counts[2]*(Counts[2]+1.0)/2.0/(Counts[1]+2*Counts[2]);
}


int C[MAXN];

int main() {
    FILE *fr, *fw;
    int N, i;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(1 == fscanf(fr, "%d", &N));
    for(i=0; i<N; i++)
        assert(1 == fscanf(fr, "%d", &C[i]));

    fprintf(fw, "%lf\n", estimate(N, C));
    fclose(fr);
    fclose(fw);
    return 0;
}
