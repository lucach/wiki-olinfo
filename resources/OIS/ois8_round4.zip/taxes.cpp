#include <stdio.h>
#include <assert.h>
#include <algorithm>

using namespace std;

int pay(int X, int Y, int Z) {
    X = max(X, 0);
    Y = max(Y, 0);
    Z = max(Z, 0);
    Z += max(Y - 5000, 0);
    Y = min(Z, 10000); // 20%
    Z -= Y; // 60%
    return X * 40 + Y * 20 + Z * 60;
}

int pay(int X, int Y, int Z, int W) {
    return min(pay(X-W,Y,Z), min(pay(X,Y-W,Z), pay(X,Y,Z-W)));
}


int main() {
    FILE *fr, *fw;
    int X, Y, Z, W;

#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(4 == fscanf(fr, "%d %d %d %d", &X, &Y, &Z, &W));

    fprintf(fw, "%d\n", pay(X, Y, Z, W));
    fclose(fr);
    fclose(fw);
    return 0;
}
