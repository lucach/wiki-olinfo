#include <bits/stdc++.h>
using namespace std;

int main() {
    int N, C;
    cin >> N >> C;

    unordered_map<int, int> dist;

    int answer = 0;

    for (int i = 0; i < N; i++) {
        int x;
        cin >> x;

        if (!dist.count(x)) {
            int new_dist = dist.size();
            dist[x] = new_dist + 1;
        }

        int num_swaps = dist[x] - 1;

        answer += num_swaps;
    }

    cout << answer << endl;
}
