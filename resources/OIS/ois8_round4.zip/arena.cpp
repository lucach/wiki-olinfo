#include <stdio.h>
#include <assert.h>

#define MAXN 100000

int frags[MAXN];
int alive;

int main() {
    FILE *fr, *fw;
    int N, E, L, P, Q, i;
    char t;
    
#ifdef EVAL
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
#else
    fr = stdin;
    fw = stdout;
#endif
    assert(3 == fscanf(fr, "%d %d %d", &N, &E, &L));
    for(i=0; i<E; i++) {
        assert(2 == fscanf(fr, "%d %c", &P, &t));
        if (t == 'f')
            assert(1 == fscanf(fr, "%d", &Q));
        else assert(t == 'e');
        assert(frags[P] < L);
        if (t == 'e') {
            frags[P]--;
            L--;
        }
        else {
            assert(frags[Q] < L);
            frags[Q]++;
        }
    }
    for (int i=alive=0; i<N; i++)
        if (frags[i] < L)
            alive++;
    fprintf(fw, "%d\n", alive);
    fclose(fr);
    fclose(fw);
    return 0;
}
